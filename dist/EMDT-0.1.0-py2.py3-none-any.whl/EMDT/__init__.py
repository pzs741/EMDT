# -*- coding: utf-8 -*-
"""
努力不需要理由，如果需要，就是为了不需要的理由。
"""
__title__ = 'emDT'
__author__ = 'Ex_treme'
__license__ = 'MIT'
__copyright__ = 'Copyright 2018, Ex_treme'

from .EMDT import EMDT

version = '0.1.0'
